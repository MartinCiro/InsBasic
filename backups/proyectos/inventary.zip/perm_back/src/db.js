// db.js (o el nombre del archivo donde defines getConnection)
const { Pool } = require("pg");
const config = require("./config");

const dbauth = {
  user: config.UserDB,
  password: config.PasswordBD,
  host: config.ServerDB,
  port: config.PortDB,
  database: config.Database,
};

async function getConnection() {
  return new Pool(dbauth);
}

module.exports = {
  getConnection,
};

