const { getConnection } = require("../../db");
const { query } = require("express");

const existe = (error, datos) => {
  const errorMessages = {
    duplicateEntry: (field) => `El ${field} ya existe`,
  };

  if (error.code === "23505") {
    const field = datos;
    throw {
      ok: false,
      status_cod: 400,
      data: errorMessages.duplicateEntry(field),
    };
  }
};

const validar = (valor, nombre) => {
  if (!valor)
    throw {
      ok: false,
      status_cod: 400,
      data: `No se ha proporcionado ${nombre}`,
    };
};

async function getAllTask() {
  const pool = await getConnection();
  return pool
    .query(
      `
          SELECT * FROM task;
          `
    )
    .then((data) => {
      if (data.rows.length > 0) {
        return data.rows;
      } else {
        // En caso de estar vacía, reinicia el serial
        return pool.query(`TRUNCATE TABLE task RESTART IDENTITY`)
        .then(() => "No se encontró información");
      }
    })
    .catch((error) => {
      if (error.status_cod) throw error;
      error.status_cod ? error : null;
      throw {
        ok: false,
        status_cod: 500,
        data: "Ha ocurrido un error consultando la información en base de datos",
      };
    })
    .finally(() => pool.end());
}

async function getTask(element) {
  const pool = await getConnection();
  return pool
    .query(
      `
          SELECT * FROM task where id=$1
          `, [element]
    )
    .then((data) => {
      return data.rows.length > 0 ? (data.rows[0]) : (data.rows = "No se encontró información");
    })
    .catch((error) => {
      console.log(error)
      if (error.status_cod) throw error;
      error.status_cod ? error : null;
      throw {
        ok: false,
        status_cod: 500,
        data: "Ha ocurrido un error consultando la información en base de datos",
      };
    })
    .finally(() => pool.end());
}

async function createTask(elements) {
  const pool = await getConnection();
  
  const params = [elements.title, elements.description];
  console.log(params)
  return pool
    .query(
      `
      INSERT INTO task (title, descripcion)
      VALUES ($1, $2) RETURNING id
          `, params
    )
    .then((data) => {
      return data.rows[0].id;
    })
    .catch((error) => {
      if (error.status_cod) throw error;
      error.status_cod ? error : null;
      existe(error, "title");
      throw {
        ok: false,
        status_cod: 500,
        data: "Ha ocurrido un error consultando la información en base de datos",
      };
    })
    .finally(() => pool.end);
}

async function deleteTask(id) {
  const pool = await getConnection();
  return pool
    .query(
      `
      DELETE FROM task
      WHERE id = $1
          `, [id]
    )
    .then((data) => {
      return data.rowCount != 0 ? "Tarea eliminada con exito" : "No se pudo eliminar, intente nuevamente";
    })
    .catch((error) => {
      if (error.status_cod) throw error;
      error.status_cod ? error : null;
      throw {
        ok: false,
        status_cod: 500,
        data: "Ha ocurrido un error consultando la información en base de datos",
      };
    })
}

async function updateTask(params) {
  const params1 = [params.title, params.description, params.id];
  
  
  const pool = await getConnection();
  return pool
    .query(
      `
      UPDATE task SET title = $1, descripcion = $2
      WHERE id = $3
          `, params1
    )
    .then((data) => {
      return data.rowCount != 0 ? "Tarea actualizada con exito" : "No se pudo actualizar, intente nuevamente";
    })
    .catch((error) => {
      if (error.status_cod) throw error;
      error.status_cod ? error : null;
      throw {
        ok: false,
        status_cod: 500,
        data: "Ha ocurrido un error consultando la información en base de datos",
      };
    })
}

module.exports = {
  existe,
  validar,
  getAllTask,
  getTask,
  createTask,
  deleteTask,
  updateTask
};
