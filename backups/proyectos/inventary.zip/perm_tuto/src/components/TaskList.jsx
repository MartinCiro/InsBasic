import { Card, CardContent, Typography, Button } from '@mui/material';
import { React, useEffect, useState } from 'react';

import {useNavigate} from 'react-router-dom';

/* import * as stylex from 'stylex'; */

/* const styles = stylex.create({
  foo: {
    color: 'red',
  },
  bar: {
    backgroundColor: 'blue',
  },
}); */

export default function Tasklist() {
  const [tasks, setTask] = useState([]);
  const navigate = useNavigate();

  const loadTasks = async () => {
    const response = await fetch('http://localhost:3000/tasks')
    const data = await response.json()
    setTask(data.status_cod)
  }
  const handleDelete = async (id) => {
    await fetch(`http://localhost:3000/tasks?id=${id}`, {
      method: 'DELETE'
    })
    setTask(tasks.filter(task => task.id !== id))
  }
  useEffect(() => { //call the function chargeData when the component is mounted
    loadTasks()
  }, []);
  return (
    <>
      <h1>Tasklist</h1>
      {
        tasks.map(task =>
          <Card key={task.id} style={{ marginBottom: '.8rem' }}>
            <CardContent style={{ display: 'flex', justifyContent: 'space-between' }}>
              <div>
                <Typography> {task.title} </Typography>
                <Typography>{task.descripcion}</Typography>
              </div>
              <div>
                <Button variant='contained' color='inherit' onClick={() => navigate(`/tasks/edit/${task.id}`)} style={{ marginRight: '.5rem' }}>
                  Edite
                </Button>
                <Button variant='contained' color='warning' onClick={() => handleDelete(task.id)}>Delete</Button>
              </div>
            </CardContent>
          </Card>
        )
      }
    </>
  )
}
